/**
 * Creates a snapshot collector.
 * Each call to snap() records the current algorithm state.
 * Returns { steps, pseudocode } after the algorithm runs.
 */
function createTracer() {
  const steps = [];

  function snap(state) {
    // Deep clone to freeze the state at this moment
    steps.push(JSON.parse(JSON.stringify(state)));
  }

  return { snap, steps };
}

module.exports = { createTracer };
