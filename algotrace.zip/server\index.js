require('dotenv').config();
const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const fetch = require('node-fetch');
const baseRegistry = require('./registry');
const { generateTrace } = require('./llmService');
const fs = require('fs').promises;
const path = require('path');

const registry = { ...baseRegistry };
const tracesDir = path.join(__dirname, 'data', 'traces');

// Lazy-load a trace from disk on demand
async function loadTrace(slug) {
  if (registry[slug]) return registry[slug];
  const filePath = path.join(tracesDir, `${slug}.json`);
  try {
    const content = await fs.readFile(filePath, 'utf8');
    registry[slug] = JSON.parse(content);
    return registry[slug];
  } catch {
    return null;
  }
}

// Pre-populate registry keys (titles/metadata only) without reading file contents
async function indexTraces() {
  try {
    const files = await fs.readdir(tracesDir);
    for (const file of files) {
      if (file.endsWith('.json')) {
        const slug = file.replace('.json', '');
        if (!registry[slug]) registry[slug] = null; // placeholder
      }
    }
  } catch { /* tracesDir may not exist */ }
}

const app = express();

app.use(cors({
  origin: process.env.ALLOWED_ORIGIN || 'http://localhost:5173',
}));
app.use(express.json());

const generateLimiter = rateLimit({
  windowMs: 60 * 1000,
  max: 10,
  message: { error: 'Too many requests. Please wait a minute.' },
});

/* ── LeetCode GraphQL ──────────────────────────────────────── */
const LC_API = 'https://leetcode.com/graphql';

async function fetchLCProblem(slug) {
  const query = `
    query getProblem($titleSlug: String!) {
      question(titleSlug: $titleSlug) {
        title
        difficulty
        content
        topicTags { name }
      }
    }
  `;
  try {
    const res = await fetch(LC_API, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Referer': 'https://leetcode.com' },
      body: JSON.stringify({ query, variables: { titleSlug: slug } }),
    });
    const json = await res.json();
    return json?.data?.question ?? null;
  } catch {
    return null;
  }
}

/* ── Routes ────────────────────────────────────────────────── */

// List all supported problems
app.get('/api/problems', (req, res) => {
  const list = Object.entries(registry)
    .filter(([, p]) => p !== null)
    .map(([slug, p]) => ({
      slug,
      title: p.title,
      difficulty: p.difficulty,
      tags: p.tags ?? [],
      supported: true,
    }));
  res.json(list);
});

// Get full trace for a problem
app.get('/api/trace/:slug', async (req, res) => {
  const { slug } = req.params;
  const local = await loadTrace(slug);

  if (!local) {
    return res.status(404).json({
      error: 'Problem not in registry yet.',
      message: `"${slug}" is not supported yet.`,
    });
  }

  // Try to enrich with live LC description
  let description = local.description;
  try {
    const lc = await fetchLCProblem(slug);
    if (lc?.content) {
      // Strip HTML tags from LC content
      description = lc.content.replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/\n{3,}/g, '\n\n').trim().slice(0, 600);
    }
  } catch { /* use local description */ }

  res.json({ ...local, description });
});

// Search problems
app.get('/api/search', (req, res) => {
  const q = (req.query.q ?? '').toLowerCase();
  const entries = Object.entries(registry).filter(([, p]) => p !== null);
  if (!q) return res.json(entries.map(([slug, p]) => ({ slug, ...p })));

  const results = entries
    .filter(([slug, p]) =>
      slug.includes(q) ||
      p.title.toLowerCase().includes(q) ||
      (p.tags ?? []).some(t => t.toLowerCase().includes(q))
    )
    .map(([slug, p]) => ({ slug, title: p.title, difficulty: p.difficulty, tags: p.tags ?? [] }));

  res.json(results);
});

// Generate dynamic trace via LLM
app.post('/api/generate', generateLimiter, async (req, res) => {
  const { slug, userCode, language } = req.body;
  if (!slug) return res.status(400).json({ error: 'Missing problem slug.' });
  if (userCode && userCode.length > 5000) return res.status(400).json({ error: 'Code exceeds maximum length of 5000 characters.' });

  try {
    let problemData = await fetchLCProblem(slug);
    if (!problemData) {
      problemData = {
        title: slug.split('-').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '),
        difficulty: 'Unknown',
        content: `A standard algorithmic problem known as ${slug.replace(/-/g, ' ')}.`,
        topicTags: []
      };
    }

    const trace = await generateTrace(problemData, userCode, language);
    res.json(trace);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: error.message || 'Failed to generate trace.' });
  }
});

indexTraces().then(() => {
  app.listen(3001, () => console.log('AlgoTrace server running on http://localhost:3001'));
});
