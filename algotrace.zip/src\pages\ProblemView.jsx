import React, { useEffect, useCallback, useRef, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Play, Pause, RotateCcw, SkipForward, SkipBack, Terminal } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

import usePlayerStore from '../store/usePlayerStore';
import { fetchProblemData, generateTraceData } from '../services/api';
import ArrayVisualizer from '../components/visualizers/ArrayVisualizer';
import LinkedListVisualizer from '../components/visualizers/LinkedListVisualizer';
import MatrixVisualizer from '../components/visualizers/MatrixVisualizer';
import TreeVisualizer from '../components/visualizers/TreeVisualizer';
import GraphVisualizer from '../components/visualizers/GraphVisualizer';
import PseudocodeBlock from '../components/PseudocodeBlock';

const SPEED_PRESETS = [
  { label: '0.5×', value: 3000 },
  { label: '1×',   value: 2000 },
  { label: '2×',   value: 1000 },
  { label: '4×',   value: 500  },
];

const DIFF_COLOR = { Easy: '#22c55e', Medium: '#f59e0b', Hard: '#ff0000' };

const ProblemView = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const [problemData, setProblemData] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isGenerating, setIsGenerating] = useState(false);
  const [generateError, setGenerateError] = useState(null);
  const [loadError, setLoadError] = useState(null);

  const consoleRef = useRef(null);

  const { currentStep, totalSteps, isPlaying, playbackSpeed, setCurrentStep, setTotalSteps, setPlaybackSpeed, togglePlay, nextStep, prevStep, reset, seekToStep } = usePlayerStore();

  useEffect(() => {
    const load = async () => {
      setIsLoading(true);
      try {
        const data = await fetchProblemData(id);
        setProblemData(data);
        setTotalSteps(data.steps.length);
      } catch (err) {
        setProblemData(null);
        setLoadError(err.status === 404 ? 'not-found' : 'network');
      }
      setIsLoading(false);
    };
    load();
    return () => reset();
  }, [id, setTotalSteps, reset]);

  useEffect(() => {
    if (consoleRef.current) {
      consoleRef.current.scrollTop = consoleRef.current.scrollHeight;
    }
  }, [currentStep]);

  const handleGenerate = async () => {
    setIsGenerating(true);
    setGenerateError(null);
    try {
      const data = await generateTraceData(id);
      setProblemData(data);
      setTotalSteps(data.steps.length);
      setCurrentStep(0);
    } catch (err) {
      setGenerateError(err.message);
    }
    setIsGenerating(false);
  };

  const handleKey = useCallback((e) => {
    if (e.target.tagName === 'INPUT') return;
    if (e.key === 'ArrowRight') nextStep();
    if (e.key === 'ArrowLeft')  prevStep();
    if (e.key === ' ') { e.preventDefault(); togglePlay(); }
    if (e.key === 'r' || e.key === 'R') setCurrentStep(0);
  }, [nextStep, prevStep, togglePlay, setCurrentStep]);

  useEffect(() => {
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [handleKey]);

  useEffect(() => {
    let t;
    if (isPlaying && currentStep < totalSteps - 1) {
      t = setInterval(nextStep, playbackSpeed);
    } else if (currentStep >= totalSteps - 1 && isPlaying) {
      togglePlay();
    }
    return () => clearInterval(t);
  }, [isPlaying, currentStep, totalSteps, playbackSpeed, nextStep, togglePlay]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-4" style={{ background: '#0a0000' }}>
        <div style={{ width: 48, height: 48, border: '2px solid #ff0000', animation: 'spin 1s linear infinite' }}
          className="flex items-center justify-center">
          <Terminal size={16} color="#ff0000" />
        </div>
        <p className="label-red">LOADING TRACE...</p>
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
      </div>
    );
  }

  if (!problemData) {
    const isNetworkError = loadError === 'network';
    return (
      <div className="min-h-screen flex flex-col items-center justify-center gap-6" style={{ background: '#0a0000' }}>
        <button onClick={() => navigate('/')} className="absolute top-8 left-8 control-btn" aria-label="Back to home">
          <ArrowLeft size={15} />
        </button>
        <Terminal size={32} color="#ff0000" />
        <h2 className="text-white text-xl font-bold tracking-tight">
          {isNetworkError ? 'Server Unreachable' : 'Trace Not Found'}
        </h2>
        <p className="text-textMuted text-sm text-center max-w-md">
          {isNetworkError
            ? 'Could not connect to the AlgoTrace server. Make sure it is running on port 3001.'
            : `"${id}" is not in our local static registry. We can dynamically generate the execution trace using the AI Engine.`
          }
        </p>
        {!isNetworkError && (
          <button onClick={handleGenerate} disabled={isGenerating} className="px-6 py-3 border border-[#ff0000] text-[#ff0000] font-mono text-xs hover:bg-[#ff0000]/10 transition-colors flex items-center gap-2 disabled:opacity-50">
            {isGenerating ? <div className="animate-spin h-3 w-3 border-2 border-[#ff0000] rounded-full border-t-transparent" /> : <Play size={12} />}
            {isGenerating ? 'GENERATING...' : 'GENERATE TRACE WITH AI'}
          </button>
        )}
        {generateError && <p className="font-mono text-xs text-[#ff4444] text-center">{generateError}</p>}
      </div>
    );
  }

  const stepData = problemData.steps[currentStep];
  const progress = totalSteps > 1 ? (currentStep / (totalSteps - 1)) * 100 : 0;

  const renderVisualizer = () => {
    switch (problemData.type) {
      case 'array':       return <ArrayVisualizer stepData={stepData} target={problemData.target} problemId={id} />;
      case 'linked-list': return <LinkedListVisualizer stepData={stepData} />;
      case 'matrix':      return <MatrixVisualizer stepData={stepData} />;
      case 'tree':        return <TreeVisualizer stepData={stepData} />;
      case 'graph':       return <GraphVisualizer stepData={stepData} />;
      default:            return <div className="label">UNKNOWN TYPE: {problemData.type}</div>;
    }
  };

  return (
    <div className="min-h-screen flex flex-col" style={{ background: '#0a0000' }}>

      {/* Top red line */}
      <div style={{ height: '1px', background: '#ff0000', boxShadow: '0 0 40px 4px rgba(255,0,0,0.3)' }} />

      {/* Header */}
      <motion.header initial={{ opacity: 0 }} animate={{ opacity: 1 }}
        className="flex items-center justify-between px-8 py-4 border-b border-borderDark">
        <div className="flex items-center gap-4">
          <button onClick={() => navigate('/')}
            className="control-btn" aria-label="Back to home">
            <ArrowLeft size={15} />
          </button>
          <div className="flex items-center gap-2 label">
            <Terminal size={11} />
            <span>ALGOTRACE</span>
            <span className="text-borderLight">/</span>
          </div>
          <h1 className="font-bold text-white text-sm tracking-tight">{problemData.title}</h1>
          <span className="font-mono text-[10px] font-bold px-2 py-0.5 border"
            style={{ color: DIFF_COLOR[problemData.difficulty] || '#22c55e', borderColor: DIFF_COLOR[problemData.difficulty] || '#22c55e', background: 'transparent' }}>
            {problemData.difficulty.toUpperCase()}
          </span>
        </div>

        <div className="hidden sm:flex items-center gap-6">
          {/* Progress bar */}
          <div className="flex items-center gap-3">
            <div className="w-32 h-px" style={{ background: '#2a0000' }}>
              <motion.div className="h-full" style={{ background: '#ff0000' }}
                animate={{ width: `${progress}%` }} transition={{ duration: 0.3 }} />
            </div>
            <span className="font-mono text-xs text-textMuted">{currentStep + 1}/{totalSteps}</span>
          </div>
          {/* Keyboard hints */}
          <div className="flex items-center gap-2 label" aria-label="Keyboard shortcuts">
            {[['←', 'Previous step'], ['→', 'Next step'], ['SPC', 'Play / Pause']].map(([k, hint]) => (
              <kbd key={k} title={hint} className="font-mono text-[10px] px-1.5 py-0.5 border border-borderDark text-textMuted cursor-help">{k}</kbd>
            ))}
          </div>
        </div>
      </motion.header>

      {/* Main layout */}
      <div className="flex-1 grid grid-cols-1 lg:grid-cols-12 gap-px" style={{ background: '#2a0000', minHeight: 0 }}>

        {/* Left col */}
        <div className="lg:col-span-8 flex flex-col gap-px" style={{ background: '#2a0000' }}>

          {/* Description */}
          <div className="mb-10 p-6 rounded-xl border border-borderDark shadow-lg" style={{ background: 'linear-gradient(145deg, #160000, #0a0000)' }}>
            <h3 className="text-[#ff4444] font-mono font-bold mb-4 flex items-center gap-2">
              <Terminal size={18} /> PROBLEM DESCRIPTION
            </h3>
            <div className="max-h-64 overflow-y-auto pr-4 scrollbar-custom">
              <p className="text-[15px] leading-relaxed" style={{ color: 'rgba(255, 255, 255, 0.85)' }}>
                {problemData.description.split('\n').map((line, i) => (
                  <span key={i}>{line}<br/></span>
                ))}
              </p>
            </div>
          </div>

          {/* Visualizer */}
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.1 }}
            className="flex flex-col flex-1" style={{ background: '#0a0000' }}>

            {/* Panel header */}
            <div className="flex items-center justify-between px-8 py-4 border-b border-borderDark">
              <div className="flex items-center gap-4">
                <p className="label">VISUALIZER</p>
                <div className="flex items-center gap-2">
                  <div style={{
                    width: 6, height: 6,
                    background: isPlaying ? '#ff0000' : '#2a0000',
                    boxShadow: isPlaying ? '0 0 8px #ff0000' : 'none',
                    transition: 'all 0.3s',
                    animation: isPlaying ? 'blink 1s step-end infinite' : 'none',
                  }} />
                  <span className="font-mono text-[10px]" style={{ color: isPlaying ? '#ff0000' : '#6b5555' }}>
                    {isPlaying ? 'RUNNING' : 'PAUSED'}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-1">
                {SPEED_PRESETS.map(({ label, value }) => (
                  <button key={value} onClick={() => setPlaybackSpeed(value)}
                    className={`speed-chip ${playbackSpeed === value ? 'speed-chip-active' : 'speed-chip-inactive'}`}>
                    {label}
                  </button>
                ))}
              </div>
            </div>

            {/* Viz content — generating overlay */}
            <div className="flex-1 flex justify-center items-center py-10 px-8 min-h-[380px] relative">
              {isGenerating && (
                <div className="absolute inset-0 z-10 flex flex-col items-center justify-center gap-3"
                  style={{ background: 'rgba(10,0,0,0.85)', backdropFilter: 'blur(2px)' }}>
                  <div style={{ width: 36, height: 36, border: '2px solid #ff0000', animation: 'spin 1s linear infinite' }}
                    className="flex items-center justify-center">
                    <Terminal size={12} color="#ff0000" />
                  </div>
                  <p className="label-red">GENERATING TRACE VIA AI...</p>
                </div>
              )}
              <AnimatePresence mode="wait">
                <motion.div key={currentStep}
                  initial={{ opacity: 0, y: 6 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -6 }}
                  transition={{ duration: 0.15 }} className="w-full">
                  {renderVisualizer()}
                </motion.div>
              </AnimatePresence>
            </div>

            {/* Execution Console */}
            <div className="mx-8 mb-6 border border-borderDark rounded-lg flex flex-col shadow-inner" style={{ background: '#110000', height: '180px' }}>
              <div className="px-4 py-2 border-b border-borderDark bg-[#0a0000] flex justify-between items-center rounded-t-lg">
                <span className="label flex items-center gap-2"><Terminal size={12}/> EXECUTION LOG</span>
                <span className="font-mono text-[10px] text-textMuted">STEP {currentStep + 1} / {totalSteps}</span>
              </div>
              <div className="flex-1 overflow-y-auto p-3 scrollbar-custom flex flex-col gap-1.5" ref={consoleRef}>
                {problemData.steps.slice(0, currentStep + 1).map((step, idx) => {
                  const isActive = idx === currentStep;
                  return (
                    <div key={idx} className={`flex items-start gap-3 p-2 rounded-md transition-colors ${isActive ? 'bg-[rgba(255,0,0,0.15)] border border-[rgba(255,0,0,0.3)] shadow-[0_0_10px_rgba(255,0,0,0.1)]' : 'border border-transparent'}`}>
                      <span className="font-mono text-[10px] mt-0.5 shrink-0" style={{ color: isActive ? '#ff4444' : '#6b5555' }}>
                        [{String(idx).padStart(2, '0')}]
                      </span>
                      <p className={`text-sm leading-relaxed ${isActive ? 'text-white font-medium' : 'text-[#888]'}`}>
                        {step.note}
                      </p>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Controls */}
            <div className="px-8 pb-8 flex flex-col gap-4 border-t border-borderDark pt-5 bg-[#0a0000]">
              <div className="flex items-center gap-3">
                <span className="font-mono text-[10px] text-[#ff4444] w-4 text-right font-bold">{currentStep}</span>
                <input type="range" min="0" max={totalSteps - 1} value={currentStep}
                  onChange={e => seekToStep(parseInt(e.target.value))} 
                  className="flex-1 h-1.5 bg-[#2a0000] rounded-full appearance-none cursor-pointer accent-[#ff0000] hover:accent-[#ff4444] transition-all outline-none" />
                <span className="font-mono text-[10px] text-textMuted w-4">{totalSteps - 1}</span>
              </div>

              <div className="flex items-center justify-center gap-2">
                <button className="control-btn" onClick={() => setCurrentStep(0)} disabled={currentStep === 0} aria-label="Reset to first step">
                  <RotateCcw size={13} />
                </button>
                <button className="control-btn" onClick={prevStep} disabled={currentStep === 0} aria-label="Previous step">
                  <SkipBack size={13} />
                </button>

                <button onClick={togglePlay} aria-label={isPlaying ? 'Pause' : 'Play'}
                  className="flex items-center justify-center transition-all duration-200"
                  style={{
                    width: 44, height: 44,
                    background: isPlaying ? '#ff0000' : 'white',
                    color: '#000',
                    border: 'none',
                    cursor: 'pointer',
                    boxShadow: isPlaying ? '0 0 24px rgba(255,0,0,0.5)' : 'none',
                  }}>
                  {isPlaying ? <Pause size={16} /> : <Play size={16} style={{ marginLeft: 2 }} />}
                </button>

                <button className="control-btn" onClick={nextStep} disabled={currentStep === totalSteps - 1} aria-label="Next step">
                  <SkipForward size={13} />
                </button>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Right: Pseudocode */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.15 }}
          className="lg:col-span-4 flex flex-col" style={{ background: '#0a0000' }}>
          <div className="flex items-center justify-between px-6 py-4 border-b border-borderDark flex-shrink-0">
            <p className="label">PSEUDOCODE</p>
            <div className="flex gap-1.5">
              <div className="w-2.5 h-2.5" style={{ background: 'rgba(255,0,0,0.5)' }} />
              <div className="w-2.5 h-2.5" style={{ background: 'rgba(255,255,255,0.15)' }} />
              <div className="w-2.5 h-2.5" style={{ background: 'rgba(255,255,255,0.05)' }} />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto py-4">
            <PseudocodeBlock code={problemData.pseudocode} activeLine={stepData.codeLine} />
          </div>
        </motion.div>

      </div>

      <style>{`
        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0} }
      `}</style>
    </div>
  );
};

export default ProblemView;
